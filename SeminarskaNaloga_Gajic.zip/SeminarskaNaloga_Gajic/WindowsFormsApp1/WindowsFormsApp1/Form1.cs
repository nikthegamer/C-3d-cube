﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Device device = null;
        private VertexBuffer vb = null;
        private IndexBuffer ib = null;
        string myPath = "Test.txt";

        CustomVertex.PositionColored[] verts = null;


        private static readonly short[] Indices =
        {
            0,1,2, 1,3,2, //frontside
            4,5,6, 6,5,7, //backside
            0,5,4, 0,2,5, //topside
            1,6,7, 1,7,3, //bottomside
            0,6,1, 4,6,0, //leftside
            2,3,7, 5,2,7 //rightside
        };

        float angle = 0.0f;

        public Form1()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.Opaque, true);

            InitializeComponent();
            InitializeGraphics();
        }

        private void InitializeGraphics() {

            PresentParameters pp = new PresentParameters();
            //Bool decides if windows or fullscreen
            pp.Windowed = true;
            //Back and front buffer, everything is setup and drawn in the back buffer SwapEffect swaps whats in the back buffer to the front buffer
            pp.SwapEffect = SwapEffect.Discard;

            pp.EnableAutoDepthStencil = true;
            pp.AutoDepthStencilFormat = DepthFormat.D16;

            device = new Device(0, DeviceType.Hardware, this, CreateFlags.HardwareVertexProcessing, pp);

            //Creates the vertex buffer and the event handler on vertex buffer creation
            vb = new VertexBuffer(typeof(CustomVertex.PositionColored), 8, device, Usage.Dynamic | Usage.WriteOnly, CustomVertex.PositionColored.Format, Pool.Default);
            vb.Created += new EventHandler(this.OnVertexBufferCreate);
            OnVertexBufferCreate(vb, null);
            //Stores data into the vertex buffer
            vb.SetData(verts, 0, LockFlags.None);

            ib = new IndexBuffer(typeof(short), Indices.Length, device, Usage.WriteOnly, Pool.Default);
            ib.Created += new EventHandler(this.OnIndexBufferCreate);
            OnIndexBufferCreate(ib, null);
        }

        private void OnIndexBufferCreate(object sender, EventArgs e)
        {
            //IndexBuffer just stores some numbers
            IndexBuffer buffer = (IndexBuffer)sender;
            buffer.SetData(Indices, 0, LockFlags.None);
        }

        private void OnVertexBufferCreate(object sender, EventArgs e)
        {
            //Creates a copy of the original vertex buffer
            VertexBuffer buffer = (VertexBuffer)sender;
            //Amount of points created
            verts = new CustomVertex.PositionColored[8];
            //Vector 3 = 3d
            //Stores the x, y and z value
            //System drawing color, system needs INTEGER

            verts[0] = new CustomVertex.PositionColored(-2, 2, 2, Color.Pink.ToArgb());
            verts[1] = new CustomVertex.PositionColored(-2, -2, 2, Color.DarkMagenta.ToArgb());
            verts[2] = new CustomVertex.PositionColored(2, 2, 2, Color.Pink.ToArgb());
            verts[3] = new CustomVertex.PositionColored(2, -2, 2, Color.DarkCyan.ToArgb());

            verts[4] = new CustomVertex.PositionColored(-2, 2, -2, Color.Cyan.ToArgb());
            verts[5] = new CustomVertex.PositionColored(2, 2, -2, Color.DarkCyan.ToArgb());
            verts[6] = new CustomVertex.PositionColored(-2, -2, -2, Color.Pink.ToArgb());
            verts[7] = new CustomVertex.PositionColored(2, -2, -2, Color.DarkMagenta.ToArgb());

            //Stores the verts data into the buffer
            buffer.SetData(verts, 0, LockFlags.None);
        }

        private void SetupCamera()
        {
            GenerateCube NumOfCubes = new GenerateCube(ReadFile(myPath));
            int x = NumOfCubes.NumOfCube;
            //Tells the device how to look into a 3d world
            //Requires float, FOV, Ratio to look at, how far and how close the camera sees objects
            device.Transform.Projection = Matrix.PerspectiveFovLH((float)Math.PI / 4, this.Width/this.Height, 1.0f, 100.0f);
            //Tells the device where to look in the 3d world
            device.Transform.View = Matrix.LookAtLH(new Vector3(GenerateCube.Camera(x)/3, 15, GenerateCube.Camera(x)/2), new Vector3(), new Vector3(0, 1.0f , 0));
            //Turning off back light so color is shown
            device.RenderState.Lighting = false;
            //To show both sides of the triangle
            device.RenderState.CullMode = Cull.CounterClockwise;

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //Clearing the device, What color to fill the device, depth of the device
            device.Clear(ClearFlags.Target | ClearFlags.ZBuffer, Color.CornflowerBlue, 1, 0);

            SetupCamera();
            //Initiate the drawing
            device.BeginScene();

            device.VertexFormat = CustomVertex.PositionColored.Format;
            //From where does it get the information it puts on the form
            //What vertex does it start from, from where it gets the vertex
            device.SetStreamSource(0, vb, 0);
            device.Indices = ib;

            GenerateCube NumOfCubes = new GenerateCube(ReadFile(myPath));
            int x = NumOfCubes.NumOfCube;

            for (int i = 0; i < x; i++)
            {
                Drawbox(angle / (float)Math.PI, angle / (float)Math.PI, angle / (float)Math.PI, i*6, 0, 0);
            }

            //End the drawing
            device.EndScene();
            //Sending information to the windows form
            device.Present();
            //Loop
            this.Invalidate();
        }

        private void Drawbox(float yaw, float pitch, float roll, float x, float y, float z)
        {
            angle += 0.02f;
            device.Transform.World = Matrix.RotationYawPitchRoll(yaw,pitch,roll)* (Matrix.Translation(x, y, z));
            device.DrawIndexedPrimitives(PrimitiveType.TriangleList, 0, 0, 8, 0, Indices.Length/3);
        }
        public int ReadFile(string myPath)
        {
            using(StreamReader sr = new StreamReader(myPath))
            {
                int i = 0;

                while (!sr.EndOfStream)
                {
                    string[] Parts = (sr.ReadLine()).Split(':');
                    i = (int.Parse(Parts[1]));
                }
                return i;
            }
        }
    }
}
