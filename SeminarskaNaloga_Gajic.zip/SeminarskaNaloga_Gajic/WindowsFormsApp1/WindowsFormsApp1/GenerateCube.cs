﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace WindowsFormsApp1
{
    class GenerateCube
    {
        public int NumOfCube;

        public GenerateCube(int n)
        {
            if (n == 0)
            {
                NumOfCube = 1;
            }
            else
            {
                NumOfCube = n;
            }
        }
        
        public static int Camera(int NumOfCube)
        {
            int x = 0;

            x = NumOfCube*-1*15;

            return x;


        }
    }
}
